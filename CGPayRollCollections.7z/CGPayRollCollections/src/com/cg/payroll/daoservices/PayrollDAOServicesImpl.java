package com.cg.payroll.daoservices;
import java.util.*;


import com.cg.payroll.beans.Associate;
public class PayrollDAOServicesImpl implements PayrollDAOServices{

	private static HashMap<Integer, Associate> associates = new HashMap<>();
	private static int ASSOCIATE_ID_COUNTER=111;
	
	public int insertAssociate(Associate associate) {
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associates.put(associate.getAssociateID(), associate);
		return associate.getAssociateID();
	}
	public boolean updateAssociate(Associate associate){
		associates.put(associate.getAssociateID(), associate);
		return true;
	}
	public boolean deleteAssociate(int associateId){
		associates.remove(associateId);
		return true;
	}
	public Associate getAssociate(int associateId){
		return associates.get(associateId);
	}
	public List<Associate> getAssociates(){
		return new  ArrayList<Associate>(associates.values());
	}

}


	