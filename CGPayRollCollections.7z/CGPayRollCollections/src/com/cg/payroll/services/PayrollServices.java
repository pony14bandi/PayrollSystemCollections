package com.cg.payroll.services;

public interface PayrollServices {

}
